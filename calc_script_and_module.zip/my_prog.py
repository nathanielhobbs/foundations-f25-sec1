try:
    with open('file_does_not_exist.txt','r') as f:
        print(f.read())
except FileNotFoundError:
    print('file does not exist')
except PermissionError:
    print('you do not have permission')
except:
    print('I do not now what went wrong')


with open('notebooks/new_file.txt','r') as f:
    contents=f.read()
    for char in contents:
        if char == ',':
            #print('oh no, not a COMMA!?!?')
            #break
            raise FileNotFoundError
            raise ERROR
        print(char)

