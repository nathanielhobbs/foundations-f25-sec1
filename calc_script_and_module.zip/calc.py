author = "Alice"

def addTwoOrMore(a, b, *args):
    return a + b + sum(args)

def multipyTwoOrMore(a, b, *args):
    result = a * b
    for i in args:
        result *= i # result = result * i
    return result

if __name__ == '__main__':
    print(addTwoOrMore(3,4))
    print(addTwoOrMore(3,4,56))
    print(addTwoOrMore(3,4,56,99,184,-26))

    print(multipyTwoOrMore(3,4))
    print(multipyTwoOrMore(3,4,56))
    print(multipyTwoOrMore(3,4,56,99,184,-26))